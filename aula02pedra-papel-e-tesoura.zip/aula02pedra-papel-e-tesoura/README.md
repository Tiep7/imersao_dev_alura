# Aula02 - Pedra,papel e tesoura

A Pen created on CodePen.

Original URL: [https://codepen.io/Pedro-Aguiar-the-lessful/pen/MYWZoVo](https://codepen.io/Pedro-Aguiar-the-lessful/pen/MYWZoVo).

